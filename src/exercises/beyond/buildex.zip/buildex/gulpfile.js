var gulp = require('gulp'),
    browserify = require('browserify'),
    buffer = require('vinyl-buffer'),
    concatCss = require('gulp-concat-css'),
    jscs,
    jshint,
    livereload,
    minifyCss = require('gulp-minify-css'),
    plumber = require('gulp-plumber'),
    prefixer = require('gulp-autoprefixer'),
    sass = require('gulp-sass'),
    source = require('vinyl-source-stream'),
    stylish,
    uglify = require('gulp-uglify'),
    watchify,

    production = process.env.NODE_ENV === 'production', // usage `NODE_ENV=production gulp build`

    path = {
        src: {
            js: 'src/**/*.js',
            client: {
                main: './src/client/js/main.js', // entry point for Browserify (leading ./ is required)
                sass: 'src/client/**/*.s[ac]ss',
                static: [ 'src/client/resources/**/*', 'src/client/*.html' ]
            },
            server: 'src/server/**/*',
        },
        dist: {
            base: 'dist/',
            all: 'dist/**/*',
            client: 'dist/client/',
            server: 'dist/server/'
        }
    },

    watching

if ( !production ) {
    // watch tasks and style checking
    jscs = require('gulp-jscs')
    jshint = require('gulp-jshint')
    livereload = require('gulp-livereload')
    stylish = require('jshint-stylish')
    watchify = require('watchify')
}

// tasks are specified as ( taskName, [ dependencies (other tasks) ], taskFunction )
gulp.task( 'default', [ 'checkstyle', 'watch', 'build' ] ) // run using `gulp`
gulp.task( 'build', [ 'sass', 'browserify', 'collectstatic', 'collectserver' ] ) // run using `gulp build`

gulp.task( 'checkstyle', function() {
    gulp.src( path.src.js )
        .pipe( plumber() )
        .pipe( jscs() )
        .pipe( jshint() )
        .pipe( jshint.reporter( stylish ) )
})

// compiles Sass/sass files, bundles them as `bundle.css`, and places it in /dist/client
gulp.task( 'sass', function() {
    gulp.src( path.src.client.sass )
            .pipe( plumber() )
            .pipe( sass() )
            .pipe( minifyCss() )
            .pipe( concatCss('bundle.css') )
            .pipe( prefixer('> 5%') )
            .pipe( gulp.dest( path.dist.client ) )
})

// Bundles JS files and places bundle.js in /dist/client. Re-bundles on changes if watching.
gulp.task( 'browserify', function() {
    var bundler = browserify({
        cache: {}, packageCache: {}, fullPaths: true,
        entries: path.src.client.main,
        debug: !production
    })

    var bundle = function() {
        var stream = bundler.bundle()
            .on( 'error', function( e ) {
                console.error( '\x1b[311m', 'Browserify Error', e.toString(), '\x1b[0m' )
            })
            .pipe( source('bundle.js') )
            .pipe( buffer() )
            .pipe( uglify() )
            .pipe( gulp.dest( path.dist.client ) )

        return stream
    }

    if ( watching ) {
        bundler = watchify( bundler )
        bundler.on( 'update', bundle )
    }

    return bundle()
})

// just copy static client files from /src to /dist
gulp.task( 'collectstatic', function() {
    gulp.src( path.src.client.static )
        .pipe( gulp.dest( path.dist.client ) )
})

// just copy server files from /src to /dist
gulp.task( 'collectserver', function() {
    gulp.src( path.src.server )
        .pipe( gulp.dest( path.dist.server ) )
})

// performs tasks when files change and reloads browser using livereload
gulp.task( 'watch', function() {
    watching = true
    livereload({ silent: true })
    gulp.watch( path.src.js, [ 'checkstyle' ] )
    gulp.watch( path.src.client.sass, [ 'sass' ] )
    gulp.watch( path.src.client.static, [ 'collectstatic' ] )
    gulp.watch( path.src.server, [ 'collectserver' ] )
    gulp.watch( path.dist.all ).on( 'change', livereload.changed )
})

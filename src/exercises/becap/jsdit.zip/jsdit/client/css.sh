#!/bin/bash
../node_modules/node-sass/bin/node-sass index.scss

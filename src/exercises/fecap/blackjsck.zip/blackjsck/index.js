var socket = io('http://localhost:8080/')


socket.on('connect', function() {
    window.startGame = function() {
        socket.emit('startgame')
    }

    socket.on('gamenotstarted', function( err ) {
        console.error('Game not started!', err)
    })

    socket.on('gamestart', function() {
        socket.on('win', function( hiddenCard ) {
            alert('You win! Your hidden card was ' + hiddenCard.value )
        })

        socket.on('bust', function( hiddenCard, debug ) {
            alert('You lose! :( Your hidden card was ' + hiddenCard.value )
            console.log( debug)
        })
    })

    $('#hit').click( function() {
        socket.emit('hit')
    })
    $('#stay').click( function() {
        socket.emit('stay')
    })
})

socket.on('card', function( card ) {
    $('<p>').html( card.value ).appendTo( document.body )
})

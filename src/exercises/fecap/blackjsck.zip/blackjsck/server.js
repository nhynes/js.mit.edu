var app = require('http').createServer(function(){})
var io = require('socket.io')(app);
var cards = require('cards')

app.listen(8080);

var numConnectedClients = 0
var connClients = {}

function numerify( letter ) {
    switch ( letter.toUpperCase() ) {
        case 'J':
            return 10
            break
        case 'Q':
            return 10
            break
        case 'K':
            return 10
            break
        case 'A':
            return 11
            break
        default:
            return parseInt( letter )
    }
}

function extractCard( card ) {
    return {
        suit: card.suit,
        value: numerify( card.value )
    }
}

var deck,
    staying
io.on('connection', function (socket) {

    numConnectedClients++
    connClients[ socket.id ] = {
        socket: socket,
        shownCards: [],
        hiddenCard: undefined,
        cardValue: 0
    }

    socket.on('hit', function() {
        if ( deck === undefined ) { return }
        var newCard = extractCard( deck.draw() ),
            clientStruct = connClients[ socket.id ]
        clientStruct.shownCards.push( newCard)
        clientStruct.cardValue += newCard.value
        socket.emit('card', newCard )
        if ( clientStruct.cardValue > 21 ) {
            socket.emit('bust', clientStruct.hiddenCard)
            Object.keys( connClients ).forEach( function( clientId ) {
                if ( clientId !== socket.id ) {
                    var client = connClients[ clientId ]
                    client.socket.emit('win', client.hiddenCard)
                }
            })
        }
    })

    socket.on('stay', function() {
        var maxClient,
            clientIds = Object.keys( connClients )
        staying++
        if ( staying === clientIds.length ) {
            maxClient = clientIds.reduce( function( maxClient, clientId ) {
                var client = connClients[ clientId ]
                if ( maxClient === undefined ) {
                    return client
                }
                return client.cardValue > maxClient.cardValue ? client : maxClient
            }, undefined )

            maxClient.socket.emit('win', maxClient.hiddenCard)
            clientIds.forEach( function( clientId ) {
                var client = connClients[ clientId ]
                if ( clientId !== maxClient.socket.id ) {
                    client.socket.emit('bust', client.hiddenCard )
                }
            })
        }
    })

    socket.on('startgame', function() {
        staying = 0
        deck = new cards.PokerDeck()

        deck.shuffleAll()

        if ( numConnectedClients < 2 ) {
            socket.emit('gamenotstarted', 'Not enough players!')
        } else {
            Object.keys( connClients )
            .forEach( function( clientId ) {
                var client = connClients[ clientId ],
                    shown = extractCard( deck.draw() ),
                    hidden = extractCard( deck.draw() )

                client.hiddenCard = hidden
                client.shownCards.push(shown)
                client.cardValue += hidden.value + shown.value
                client.socket.emit( 'gamestart' )
                client.socket.emit( 'card', shown )
            })
        }
    })

    socket.on('disconnect', function() {
        numConnectedClients--
        delete connClients[ socket.id ]
    })
});

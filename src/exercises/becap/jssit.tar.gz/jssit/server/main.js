var credentials = {
        user: 'nhynes',
        pass: 'p'
    },
    app = require('express')(),
    bodyParser = require('body-parser'),
    mysql = require('mysql'),
    path = require('path'),
    serveStatic = require('serve-static'),
    sql = mysql.createConnection({
        host: 'localhost',
        user: credentials.user,
        password: credentials.pass,
        database: credentials.user,
        supportBigNumbers: true
    })

app.use( serveStatic( path.resolve( __dirname, '..', 'client' ) ) )
app.use( bodyParser.urlencoded({ extended: false }) )
app.use( bodyParser.json() )

app.all( '*', function( req, res, next ) {
    res.set({
        'Access-Control-Allow-Origin': '*',
        'Access-Control-ALlow-Methods': 'GET, POST, PATCH, PUT, DELETE', // Semantic HTTP = on
        'Content-Type': 'application/json' // this API returns JSON!
    })
    next()
})

// Task 1 - Implement Post posting
app.post( '/posts', function( req, res ) {
    var title = req.body.title,
        message = req.body.message,
        insertData = { title: title, message: message }

    if ( !title || !message ) {
        return res.status( 400 ).send('A title and message must be supplied')
    }

    sql.query( 'INSERT INTO posts SET ?', insertData, function( err, result ) {
        if ( err ) { console.error( err ) }
        res.status( err ? 500 : 200 ).send( err? { error: err } : { id: result.insertId } )
    })
})


// Task 2 - Implement Comment posting
app.post( '/posts/:postId', function( req, res ) {
    var postId = req.params.postId,
        message = req.body.message,
        insertData = { 'postId': postId, message: message }

    if ( !message ) {
        return res.status( 400 ).send('A message must be supplied')
    }

    sql.query( 'INSERT INTO comments SET ?', insertData, function( err, result ) {
        if ( err && err.code === 'ER_NO_REFERENCED_ROW_2' ) {
            res.sendStatus( 404 )
        } else if ( err ) {
            console.error( err )
            res.sendStatus( 500 )
        } else {
            res.send({})
        }
    })
})

// Task 3 - Implement getting a Post and its Comments
app.get( '/posts/:postId', function( req, res ) {
    var postId = req.params.postId

    sql.query( 'SELECT * FROM posts WHERE id = ?', postId, function( err, posts ) {
        if ( err ) {
            console.error( err )
            return res.sendStatus( 500 )
        }

        if ( posts.length === 0 ) {
            return res.sendStatus( 404 )
        }

        var post = posts[0]

        sql.query( 'SELECT * FROM comments WHERE postId = ?', postId, function( err, comments ) {
            if ( err ) {
                console.error( err )
                return res.sendStatus( 500 )
            }

            post.comments = comments.map( function( comment ) {
                delete comment.postId
                return comment
            })

            res.send( post )
        })
    })
})

// Task 4 - Upvotes and Downvotes
app.patch( '/posts/:postId', function( req, res ) {
    var inc = req.body.increment,
        postId = req.params.postId

    if ( inc === undefined ) {
        return res.sendStatus( 400 )
    }

    sql.query( 'UPDATE posts SET score=score+? WHERE id = ?', [ inc === 'true' ? 1 : -1, postId ], function( err, result ) {
        if ( err ) {
            console.error( err )
            return res.sendStatus( 500 )
        }
        res.sendStatus( result.changedRows === 0 ? 404 : 200 )
    })
})


app.get( '/posts', function( req, res ) {
    var pageNo = parseInt( req.query.pageNumber ) || 1,
        POSTS_PER_PAGE = 25,
        offset = (pageNo - 1) * POSTS_PER_PAGE,

        COUNT_TOTAL_POSTS = 'SELECT COUNT(*) AS totalPosts FROM posts',
        GET_POSTS_AND_COMMENT_COUNT = 'SELECT posts.*, count(comments.id) AS numComments FROM posts LEFT JOIN comments ON comments.postid = posts.id GROUP BY posts.id ORDER BY posts.score DESC, numComments DESC LIMIT ?, 25'

    sql.query( COUNT_TOTAL_POSTS, function( err, results ) {
        var totalPosts

        if ( err ) {
            console.error( err )
            return res.sendStatus( 500 )
        }

        totalPosts = results[0].totalPosts

        sql.query( GET_POSTS_AND_COMMENT_COUNT, offset, function( err, results ) {
            if ( err ) {
                console.error( err )
                return res.sendStatus( 500 )
            }

            res.send({
                nextPage: offset + POSTS_PER_PAGE > totalPosts ? undefined : pageNo + 1,
                prevPage: offset - POSTS_PER_PAGE < 0 ? undefined : pageNo - 1,
                posts: results.map( function( post ) {
                    delete post.message
                    return post
                })
            })
        })
    })
})

app.listen( 8888 )
